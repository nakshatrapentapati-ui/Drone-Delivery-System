import streamlit as st

st.set_page_config(

    page_title="Drone Delivery AI",

    page_icon="🚁",

    layout="wide"

)

st.title(
    "🚁 Autonomous Drone Delivery System"
)

st.subheader(
    "Computational Foundations for Artificial Intelligence"
)

st.markdown("---")

st.info(
    "Use the sidebar to navigate through the project."
)

st.write("""

CO1 → Agent & Environment

CO2 → A* Search

CO3 → CSP Constraints

CO4 → Utility Decision Making

CO5 → Probabilistic Weather

CO6 → Hybrid AI System

""")

st.success(
    "System Ready"
)