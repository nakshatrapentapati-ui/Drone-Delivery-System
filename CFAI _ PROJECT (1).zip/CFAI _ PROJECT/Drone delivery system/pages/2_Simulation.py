import streamlit as st

from environment import HyderabadEnvironment
from search_algorithms import SearchAlgorithms
from csp import ConstraintSystem
from probabilistic import ProbabilitySystem
from decision_logic import DecisionSystem

env = HyderabadEnvironment()
search = SearchAlgorithms()
csp = ConstraintSystem()
probability = ProbabilitySystem()
decision = DecisionSystem()

st.title("🚁 Autonomous Drone Delivery Simulation")

st.markdown("---")

locations = list(env.locations.values())

source = st.selectbox(
    "📍 Select Source",
    locations
)

destination = st.selectbox(
    "🎯 Select Destination",
    locations
)

battery = st.slider(
    "🔋 Battery Percentage",
    1,
    100,
    50
)

package_type = st.selectbox(
    "📦 Package Type",
    [
        "Medicine",
        "Electronics",
        "Food",
        "Clothes",
        "Books"
    ]
)

weight = st.number_input(
    "⚖ Package Weight (KG)",
    min_value=1,
    max_value=20,
    value=5
)

st.progress(battery)

st.markdown("---")

if st.button("🚀 Start Simulation"):

    # ======================
    # WEATHER
    # ======================

    weather = probability.weather_prediction()

    weather_score = (
        probability.weather_score(
            weather
        )
    )

    risk_level, probability_value = (
        probability.bayesian_weather_risk(
            weather
        )
    )

    if weather == "Clear":

        weather_icon = "☀️"

    elif weather == "Windy":

        weather_icon = "🌬️"

    else:

        weather_icon = "🌧️"

    # ======================
    # TRAFFIC
    # ======================

    traffic_name, traffic_penalty = (
        env.get_traffic()
    )

    # ======================
    # ROUTE PLANNING (A*)
    # ======================

    path = search.astar(
        env.city_map,
        source,
        destination
    )

    # ======================
    # DISTANCE
    # ======================

    total_distance = 0

    if len(path) > 1:

        for i in range(
            len(path) - 1
        ):

            current = path[i]

            nxt = path[i + 1]

            total_distance += (
                env.city_map[current][nxt]
            )

    # ======================
    # CSP CHECK
    # ======================

    valid, constraint_message = (
        csp.validate_route(
            path,
            total_distance
        )
    )

    # ======================
    # TIME CALCULATION
    # ======================

    if traffic_name == "Low":

        speed = 60

    elif traffic_name == "Medium":

        speed = 40

    else:

        speed = 25

    delivery_time = (
        total_distance / speed
    ) * 60

    # ======================
    # UTILITY
    # ======================

    utility_score = (
        decision.utility_function(
            total_distance,
            weather_score,
            traffic_penalty,
            battery
        )
    )

    final_decision = (
        decision.evaluate_delivery(
            utility_score
        )
    )

    # ======================
    # OUTPUT
    # ======================

    st.success(
        "Simulation Completed Successfully"
    )

    col1, col2, col3 = st.columns(3)

    with col1:

        st.metric(
            "Distance",
            f"{total_distance} KM"
        )

    with col2:

        st.metric(
            "Time",
            f"{delivery_time:.2f} Min"
        )

    with col3:

        st.metric(
            "Utility",
            utility_score
        )

    st.markdown("---")

    # WEATHER

    st.subheader(
        "🌦 Weather Analysis"
    )

    st.write(
        f"{weather_icon} {weather}"
    )

    st.write(
        f"Risk Level: {risk_level}"
    )

    st.write(
        f"Probability: {probability_value:.2f}"
    )

    st.markdown("---")

    # TRAFFIC

    st.subheader(
        "🚦 Traffic Status"
    )

    if traffic_name == "Low":

        st.success(
            "🟢 Low Traffic"
        )

    elif traffic_name == "Medium":

        st.warning(
            "🟡 Medium Traffic"
        )

    else:

        st.error(
            "🔴 High Traffic"
        )

    # ROUTE

    st.subheader(
        "🗺 Planned Route"
    )

    route_text = (
        " ➜ ".join(path)
    )

    st.code(route_text)

    # CSP

    st.subheader(
        "📋 Constraint Status"
    )

    if valid:

        st.success(
            constraint_message
        )

    else:

        st.error(
            constraint_message
        )

    # UTILITY

    st.subheader(
        "🧠 Utility Evaluation"
    )

    if utility_score >= 80:

        st.success(
            f"Utility Score: {utility_score}"
        )

    else:

        st.error(
            f"Utility Score: {utility_score}"
        )

    # DECISION

    st.subheader(
        "✅ Final Decision"
    )

    if "Approved" in final_decision:

        st.success(
            final_decision
        )

    else:

        st.error(
            final_decision
        )