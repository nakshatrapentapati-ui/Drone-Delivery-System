import streamlit as st
import pandas as pd

st.title("📊 Drone Delivery Analytics")

performance = pd.DataFrame({

    "Metrics": [

        "Battery",
        "Weather",
        "Traffic",
        "Utility"

    ],

    "Values": [

        80,
        100,
        10,
        150

    ]
})

st.subheader(
    "Performance Analysis"
)

st.bar_chart(
    performance.set_index(
        "Metrics"
    )
)

coverage = pd.DataFrame({

    "CO": [

        "CO1",
        "CO2",
        "CO3",
        "CO4",
        "CO5",
        "CO6"

    ],

    "Implementation": [

        100,
        100,
        100,
        100,
        100,
        100

    ]
})

st.subheader(
    "CFAI Coverage"
)

st.line_chart(
    coverage.set_index("CO")
)

st.success(
    "All CFAI Outcomes Covered"
)