import streamlit as st

st.set_page_config(
    page_title="AI Drone Dashboard",
    page_icon="🚁",
    layout="wide"
)

st.title("🚁 Autonomous Drone Delivery Control Center")

st.markdown("---")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric(
        "Active Drones",
        "24",
        "+3"
    )

with col2:
    st.metric(
        "Deliveries Today",
        "187",
        "+21"
    )

with col3:
    st.metric(
        "Success Rate",
        "98.4%",
        "+0.5%"
    )

with col4:
    st.metric(
        "Weather Status",
        "Clear"
    )

st.markdown("---")

st.header("🔋 Drone Fleet Status")

st.progress(85)

st.write("Fleet Battery Capacity : 85%")

st.markdown("---")

st.header("🚦 Traffic Monitoring")

traffic = st.selectbox(
    "Current Traffic",
    ["Low", "Medium", "High"]
)

if traffic == "Low":
    st.success("Low Traffic")

elif traffic == "Medium":
    st.warning("Medium Traffic")

else:
    st.error("High Traffic")

st.markdown("---")

st.header("🧠 CFAI Modules Active")

st.write("""
✅ CO1 - Intelligent Agent & Environment

✅ CO2 - A* Search Route Planning

✅ CO3 - Constraint Satisfaction

✅ CO4 - Utility Based Decision Making

✅ CO5 - Probabilistic Weather Reasoning

✅ CO6 - Hybrid AI Architecture
""")

st.markdown("---")

st.success("System Status : ONLINE")